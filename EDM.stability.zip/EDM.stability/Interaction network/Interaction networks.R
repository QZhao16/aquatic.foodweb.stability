


# L4, Western English Channel

library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)1.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
#
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-14),seq(2,14, by=2), seq(18,24,by=2), c(8,10,12) )  
layout.matrix.c[,2]<-c(rep(1,26), rep(2,7), rep(2.5,4), rep(3,3) )  


V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 
Cairo(file="Western English Channel.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #

colorsss<-rep("#006600", 40)  
colorsss[27:33]<-rep("#3366FF")  
colorsss[34:37]<-rep("yellow")  
colorsss[38:40]<-rep("#CCCCCC")  

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=2,                            
            vertex.size=9,                                
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Western English Channel",cex.main=5,col.main="black")


dev.off()







# -------------------#
#--- food web figures# Lake Monona
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)



otago.links.data<-read.csv("caus_ord_lag(mae)2.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-10), seq(4,16,by=2),c(18,20),c(10)) 
layout.matrix.c[,2]<-c(rep(1,25), rep(2,7), rep(2.5,2),c(3))  




 

V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 

Cairo(file="Lake Monona.png", type="png", units="mm", width=250, height=250, pointsize=11,  dpi=600) #

colorsss<-rep("#006600", 35)   
colorsss[c(26:32)]<-rep("#3366FF")  
colorsss[c(33:34)]<-rep("yellow") # yellow
colorsss[35]<-rep("#CCCCCC") 

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=2,                            
            vertex.size=9,                                
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Lake Monona",cex.main=5,col.main="black")


dev.off()





# -------------------#
#--- food web figures# Lake Mendota
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)3.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)
colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-11), seq(2.5,8.5,by=1.3), seq(11,14,by=1.5), seq(5,9,by=1.5)) 
layout.matrix.c[,2]<-c(rep(1,16), rep(2,5), rep(2.5,3),rep(3,3) )  



V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 

Cairo(file="Lake Mendota.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #

colorsss<-rep("#006600", 27)   
colorsss[c(17:21)]<-rep("#3366FF")  
colorsss[c(22:24)]<-rep("yellow") # yellow
colorsss[25:27]<-rep("#CCCCCC") # gray 

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                            
            vertex.size=13,                                
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Lake Mendota",cex.main=5,col.main="black")


dev.off()






# -------------------#
#--- food web figures# Lake Allequash 
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)4.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)
colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-6),seq(3,7,by=1.5), seq(12,15,by=1.5) ) 
layout.matrix.c[,2]<-c(rep(2,17), rep(2.5,3), rep(3,3) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
Cairo(file="Lake Allequash.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 23)        
colorsss[c(18:20)]<-rep("#3366FF")  
colorsss[c(21:23)]<-rep("yellow")   # yellow

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                            
            vertex.size=13,                                
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Lake Allequash",cex.main=5,col.main="black")


dev.off()






# -------------------#
#--- food web figures# Lake Big Muskellunge 
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)




otago.links.data<-read.csv("caus_ord_lag(mae)5.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)
colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-6), seq(11,15,by=2),seq(3,7,by=2) ) 
layout.matrix.c[,2]<-c(rep(2,18), rep(2.5, 3),  rep(2.8, 3) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    

Cairo(file="Lake Big Muskellunge.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 24)        
colorsss[c(19:21)]<-rep("#3366FF")  
colorsss[c(22:24)]<-rep("yellow")   # yellow

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                            
            vertex.size=13,                                
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Lake Big Muskellunge",cex.main=5,col.main="black")


dev.off()




# -------------------#
#--- food web figures# Lake Sparkling (SP)
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)6.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)
colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-4),c(5,7,9), 16) 
layout.matrix.c[,2]<-c(rep(2,20), rep(2.5,3), rep(2.8,1) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 


Cairo(file="Lake Sparkling.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #

colorsss<-rep("#006600", 24)        
colorsss[c(21:23)]<-rep("#3366FF")    
colorsss[c(24)]<-rep("yellow")    # yellow

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                            
            vertex.size=12,                                
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Lake Sparkling",cex.main=5,col.main="black")


dev.off()






# -------------------#
#--- food web figures# Lake Trout (TR)
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)7.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)
colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-6),seq(3,7.5,by=1.5), c(10,12) ) 
layout.matrix.c[,2]<-c(rep(2,15), rep(2.5,4), rep(2.8,2) )  


V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 
Cairo(file="Lake Trout.png", type="png", units="mm", width=250, height=250, pointsize=11,  dpi=600) #

colorsss<-rep("#006600", 21)        
colorsss[c(16:19)]<-rep("#3366FF")    
colorsss[c(20:21)]<-rep("yellow")    # yellow

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                            
            vertex.size=13,                                
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Lake Trout",cex.main=5,col.main="black")


dev.off()





# -------------------#
#--- food web figures# 14, Lake Oneida
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)8.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-8),seq(12,17, by=1.5), seq(5,9, by=1.5), c(13) ) 
layout.matrix.c[,2]<-c(rep(1,18), rep(2,4), rep(2.5,3), rep(3,1))  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 


Cairo(file="Lake Oneida.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #

colorsss<-rep("#006600", 26)  
colorsss[19:22]<-rep("#3366FF")  
colorsss[23:25]<-rep("yellow") # yellow
colorsss[26]<-rep("#CCCCCC") # gray  



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                           
            vertex.size=13,   #10                             
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                
            edge.curved=rep(0.0, ecount(otago.graph.c)),    
            mark.shape = 3.5,
            edge.arrow.size=2,                              
            main=""
)
title("Lake Oneida",cex.main=5,col.main="black")


dev.off()




# -------------------#
#--- food web figures# 17, Narragansett Bay
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)9.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-2),c(11,17) ) # 28-2
layout.matrix.c[,2]<-c(rep(1,25), rep(2,2))  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 
Cairo(file="Narragansett Bay.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #

colorsss<-rep("#006600", 27)  
colorsss[26:27]<-rep("#3366FF")  

plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=2,                            
             
            vertex.size=10,                               
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Narragansett Bay",cex.main=5,col.main="black")


dev.off()





# -------------------#
#--- food web figures# Wadden Sea
#--------------------#
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)10.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-8),seq(2,5.5, by=0.6),  c(5.8,6.5) )  
layout.matrix.c[,2]<-c(rep(1,7), rep(2,6), rep(3,2) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 

Cairo(file="Wadden Sea.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 15)  
colorsss[8:13]<-rep("#3366FF")  
colorsss[14:15]<-rep("yellow")  



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=3,                            
             
            vertex.size=18,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Wadden Sea",cex.main=5,col.main="black")


dev.off()





########################
# effect on eigenvalue #  Estuary of the Patapsco River
########################


library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)11.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(1:(length(V(otago.graph.c))-8),seq(3,10, by=1) )  
layout.matrix.c[,2]<-c(rep(1,12), rep(2,8) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 



Cairo(file="Estuary of Patapsco River.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 20)  
colorsss[13:20]<-rep("#3366FF")  




plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                            
             
            vertex.size=14,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of Patapsco River",cex.main=5,col.main="black")


dev.off()






########################
# effect on eigenvalue #  Estuary of Elk River
########################


library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae)12.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,7, by=1.2), 7, seq(-3,6, by=0.7)[1:3], 8, seq(-3,6, by=0.7)[4:13], c(3) )  
layout.matrix.c[,2]<-c(rep(1,6), c(2.5,2,2,2,2.5), rep(2,10), rep(3,1) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 



Cairo(file="Estuary of Elk River.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 22)  
colorsss[7:21]<-rep("#3366FF")  
colorsss[c(7,11)]<-rep("yellow")  
colorsss[22:22]<-rep("#CCCCCC")  



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=3,                            
             
            vertex.size=13,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=2,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of Elk River",cex.main=5,col.main="black")


dev.off()





########################
# effect on eigenvalue # " Estuary of south river"
########################

library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)13.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,12, by=1.2)[1:8], seq(-1,17.3, by=0.7)[1:3], 9, seq(-1,17.3, by=0.7)[4:14], c(3) )  
layout.matrix.c[,2]<-c(rep(1,8), rep(2,3), c(2.5), rep(2,11), rep(3,1) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 



Cairo(file="Estuary of south river.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 24)  
colorsss[9:23]<-rep("#3366FF")  
colorsss[c(12)]<-rep("yellow")  
colorsss[24:24]<-rep("#CCCCCC")  



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   
            vertex.label.cex=3,                            
             
            vertex.size=13,                                
             
            layout=layout.matrix.c,                         
            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=1.4,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of south river",cex.main=5,col.main="black")


dev.off()





########################
# effect on eigenvalue # " Estuary of Choptank river"
########################

library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)14.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,16, by=1), seq(3,10, by=1) )  
layout.matrix.c[,2]<-c(rep(1,16), rep(2,8) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 

Cairo(file="Estuary of Choptank river.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 24)  
colorsss[17:24]<-rep("#3366FF")  
 



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=2,                            
             
            vertex.size=13,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=1.4,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of Choptank river",cex.main=5,col.main="black")


dev.off()




########################
# effect on eigenvalue # " Estuary of Bush river"
########################


library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)15.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,17, by=1.2)[1:12], seq(-3,17.3, by=0.8)[1:4], 12.5,13.8, seq(-3,17.3, by=0.8)[5:20], c(3) )  
layout.matrix.c[,2]<-c(rep(1,12), rep(2,4), c(2.5,2.5), rep(2,16), rep(3,1) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 

Cairo(file="Estuary of Bush river.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 35)  
colorsss[13:34]<-rep("#3366FF")  
colorsss[c(17,18)]<-rep("yellow")  
colorsss[35:35]<-rep("#CCCCCC")  



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=2,                            
             
            vertex.size=12,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=1.4,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of Bush river",cex.main=5,col.main="black")


dev.off()





########################
# effect on eigenvalue #  Estuary of magothy river
########################

library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)16.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,17, by=1)[1:9], seq(3,17.3, by=0.6)[1:3], 1,  seq(3,17.3, by=0.6)[4:10] )  
layout.matrix.c[,2]<-c(rep(1,9), rep(2,3), c(2.5), rep(2,7) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 


Cairo(file="Estuary of magothy river.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 20)  
colorsss[10:20]<-rep("#3366FF")  
colorsss[c(13)]<-rep("yellow")  



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=3,                            
             
            vertex.size=15,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=1.4,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of magothy river",cex.main=5,col.main="black")


dev.off()





########################
# effect on eigenvalue # " Estuary of Patuxent river"
########################

library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)17.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,17, by=1)[1:15], seq(5,17.3, by=0.8)[1:7] )  
layout.matrix.c[,2]<-c(rep(1,15), rep(2,7) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 



Cairo(file="Estuary of Patuxent river.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 22)  
colorsss[16:22]<-rep("#3366FF")  




plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=2.5,                            
             
            vertex.size=13,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=1.4,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of Patuxent river",cex.main=5,col.main="black")


dev.off()




########################
# effect on eigenvalue #" Estuary of York river"
########################
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)18.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,17, by=1)[1:7], seq(-0.5,17.3, by=0.6)[1], 6, seq(-0.5,17.3, by=0.6)[2:3],7,  seq(-0.5,17.3, by=0.6)[4:9],3 )  
layout.matrix.c[,2]<-c(rep(1,7), 2, 2.5,rep(2,2),2.5, rep(2,6),3 )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 



Cairo(file="Estuary of York river.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 19)  
colorsss[8:18]<-rep("#3366FF")  
colorsss[c(9,12)]<-rep("yellow")  
colorsss[19]<-rep("#CCCCCC")  



plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=3,                            
             
            vertex.size=15,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=1.4,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of York river",cex.main=5,col.main="black")


dev.off()






########################
# effect on eigenvalue # " Estuary of Potomac river"
########################

library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)

otago.links.data<-read.csv("caus_ord_lag(mae)19.csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance==1   )  
dim(otago.links.data)

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
ind.otago.c<-GenInd(otago.adjmatrix.c)
troph.otago.c<-TrophInd(otago.adjmatrix.c)

layout.matrix.c<-matrix(
  nrow=length(V(otago.graph.c)),   
  ncol=2
)

 
layout.matrix.c[,1]<-c(seq(1,20, by=1)[1:20], seq(6,18, by=1)[1:9] )  
layout.matrix.c[,2]<-c(rep(1,20), rep(2,9) )  




 
V(otago.graph.c)$color<-ifelse(troph.otago.c$TL<='1', "red", ifelse(troph.otago.c$TL=='2', "blue", ifelse(troph.otago.c$TL=='3', "black", "purple"))) ###set cicle color by trophic level
V(otago.graph.c)$label.color <- "black"    
 
 

Cairo(file="Estuary of Potomac river.png", type="png", units="mm", width=250, height=250, pointsize=10,  dpi=600) #


colorsss<-rep("#006600", 29)  
colorsss[21:29]<-rep("#3366FF")  
 




plot.igraph(otago.graph.c,
            xlim = c(-1, 1),   
            ylim = c(-1, 1),   

            vertex.label.cex=2.5,                            
             
            vertex.size=12,                                
             
            layout=layout.matrix.c,                         

            vertex.color= colorsss,
            edge.color="black",                             
            edge.width=1.4,	                                 
            edge.curved=rep(0.0, ecount(otago.graph.c)),   
            mark.shape = 3.5,
            edge.arrow.size=2,                             
            main=""
)
title("Estuary of Potomac river",cex.main=5,col.main="black")


dev.off()