load("function.R")


library('rEDM')#'1.2.3'
library('dplyr')
library('tidyr')
library('igraph')
library('MASS')
library('NetIndices')
library('Cairo')
library('vegan')
library('Kendall') 
library('doParallel')
library('parallel')
library('foreach')
library('glmnet')
library('psych')
library('pracma')

#
new_alg_zoo<-read.csv("P.temprature_4_per_years.LE2.2.csv")
dim(new_alg_zoo) 

# scale
alga_zo<-apply(new_alg_zoo[,2:dim(new_alg_zoo)[[2]]], 2, scale) 


E_alg_zoo<-NULL
for (i in 1:dim(alga_zo)[[2]] ) {
  
  sim_r <- simplex(alga_zo[,i],lib=c(1,floor(nrow(alga_zo)/2)),pred=c(floor(nrow(alga_zo)/2)+1,nrow(alga_zo)),E=c(2:9))
  (E_r <-sim_r[which.min(sim_r$mae),"E"][1]) 
  E_alg_zoo <- rbind(E_alg_zoo,E_r)}

dim(E_alg_zoo)  
#
write.csv(E_alg_zoo,"E_alg_zoo(mae24).csv")

##############################################
# part 2          causality+time delay       #
##############################################
E_alg_zoo<-read.csv("E_alg_zoo(mae24).csv")
E_alg_zoo[,2]

########## 
i_j_rho<-NULL
j_rho<-NULL

for (i in 1:ncol(alga_zo) ) {
  for (j in 1:ncol(alga_zo) ) {
    lag_rho<-NULL
    
    for (lags in -2:0) {   
      E_star<- E_alg_zoo[i,2]
      
      dat_temp <- alga_zo[,c(i,j)]  
      
      block_temp = data.frame(laf(dat_temp[,1],dat_temp[,2],lagf=lags))  
      colnames(block_temp) = c("RUE","Diversity")                        
      
      lib_ccm <- c(1,NROW(block_temp))
      pred_ccm <- make_pred_nozero(block_temp$RUE,E_star)
      df.out.ccm <- ccm(block=block_temp,
                        E=E_star,
                        lib=lib_ccm,        
                        pred = pred_ccm,    
                        lib_column = 1,     
                        target_column = 2,  
                        lib_sizes = NROW(block_temp),    
                        exclusion_radius=0,
                        random_libs = FALSE,
                        num_sample=1,
                        tp = 0)
      
      lag_rho<-cbind(lag_rho, df.out.ccm$rho)} 
    
    j_rho<-cbind(i,j,lag_rho)
    i_j_rho<-rbind(i_j_rho,j_rho)
  }
  
}

# 
write.csv(i_j_rho,"rho_realdata.csv") 


##### find maximum lag #######
rho_realdata<-read.csv("rho_realdata.csv")
head(rho_realdata)
dim(rho_realdata) 
rho_realdata[,4]

##
a<-NULL
b<-NULL
c<-NULL
d<-NULL

out <- data.frame(i=rep(NA,dim(rho_realdata)[[1]]),j=rep(NA,dim(rho_realdata)[[1]]),lag=rep(NA,dim(rho_realdata)[[1]]), maximum_rho=rep(NA,dim(rho_realdata)[[1]]))

for (i in 1:dim(rho_realdata)[[1]]) { 
  a<-rho_realdata[i,4:dim(rho_realdata)[[2]]]
  a[is.na(a)] <- 0
  a[which(a<0)]<-0
  b<-which.max(a)
  c<-a[which.max(a)]
  
  out[i,1]<- rho_realdata$i[i]
  out[i,2]<-rho_realdata$j[i]
  
  out[i,3]<- (b-3)
  out[i,4]<-c[[1]]
  
}

dim(out)
head(out)

#
write.csv(out,"rho_realdata_pluslag.csv")



##### define delta rho 
new_alg_zoo<-read.csv("P.temprature_4_per_years.LE2.2.csv")
dim(new_alg_zoo) 

# scale
alga_zo<-apply(new_alg_zoo[,2:dim(new_alg_zoo)[[2]]], 2, scale) # no year
head(alga_zo)
dim(alga_zo) 

#
maximum_lag_realdata<-read.csv("rho_realdata_pluslag.csv")
head(maximum_lag_realdata)
length(maximum_lag_realdata[,2])  
maximum_lag_realdata[,4]          

#
E_alg_zoo<-read.csv("E_alg_zoo(mae24).csv")
E_alg_zoo[,2]

########################## 
i_j_rho<-NULL
j_rho<-NULL
for (i in 1:dim(alga_zo)[[2]]) {
  for (j in 1:dim(alga_zo)[[2]]) {
    
    rho_difference<-NULL
    
    E_star<- E_alg_zoo[i,2]
    k<-(i-1)*dim(alga_zo)[[2]]+j
    
    dat_temp <- alga_zo[,c(i,j)]
    
    block_temp = data.frame(laf(dat_temp[,1],dat_temp[,2],lagf=maximum_lag_realdata[k,4])) 
    colnames(block_temp) = c("RUE","Diversity")
    
    out.temp <- ccm(block=block_temp,
                    E=E_star,
                    lib_column = 1,
                    target_column = 2,
                    lib_sizes = seq(10, nrow(block_temp), by = 10),
                    random_libs = F, 
                    tp=0) 
    
    out.temp$rho[is.na(out.temp$rho)]<-0                
    out.temp$rho[which(!is.finite(out.temp$rho))] <- 0  
    
    out.temp_means <- ccm_means(out.temp)
    differenc<-out.temp_means$rho[length(out.temp_means$rho)]-out.temp_means$rho[1]
    rho_difference<-cbind(rho_difference, differenc) 
    
    # Kendall's tau test and Student's t-test aresiginificant
    np<-nrow(block_temp);
    crirho <- qt(0.95,np-1)/(np-2+qt(0.95,np-1)^2);
    kend <- MannKendall(out.temp$rho);  # Kendall's tau test for mononotic increase,both (1) Kendall's tau and (2) terminal rho are significantly larger than zero
    significance_mononotic <- (kend$tau[1]>0)*(kend$sl[1]<0.05)*(out.temp_means$rho[length(out.temp_means$rho)]>crirho) # ccm.sig records the significance of each CCM
    P_value_mono<-kend$sl[1]
    rho_mono<-out.temp_means$rho[length(out.temp_means$rho)]
    
    j_rho<-cbind(i,j,maximum_lag_realdata[k,4],rho_difference,significance_mononotic,P_value_mono,rho_mono)
    i_j_rho<-rbind(i_j_rho,j_rho)
    
  }
}

write.csv(i_j_rho,"rho_difference_E.csv")




## 
maximum_lag_realdata<-read.csv("rho_realdata_pluslag.csv")
length(maximum_lag_realdata[,2])  
maximum_lag_realdata[,3]   
# 
rho_diff<-read.csv("rho_difference_E.csv")
rho_diff$significance<-ifelse(rho_diff$significance_mononotic==1,1,0) 

head(rho_diff)

maximum_lag_rho_difference<-cbind(rho_diff,maximum_lag_realdata[,5])
write.csv(maximum_lag_rho_difference,"maxlag_rhodifer.csv")



################ceating surrogates
new_alg_zoo<-read.csv("P.temprature_4_per_years.LE2.2.csv")
dim(new_alg_zoo) 
# scale
alga_zo<-apply(new_alg_zoo[,2:dim(new_alg_zoo)[[2]]], 2, scale) 
head(alga_zo)
dim(alga_zo) 


#
alga_zoo<-read.csv("P.temprature_4_per_years.LE2.2.csv")
Date<-as.Date(alga_zoo$sampledate,"%m/%d/%Y")
#
E_alg_zoo<-read.csv("E_alg_zoo(mae24).csv")
E_alg_zoo[,2]

######################## generating surrogates

surrogate_allspeceis<-NULL
for (j in 1:dim(alga_zo)[[2]]) {
  
  df.in<-data.frame (date = Date, Diversity = alga_zo[,j])
  
  set.seed(599213) 
  
  out_diversity <- yearday_anom(df.in$date,df.in$Diversity)
  Diversity.bar <- out_diversity$mean
  Diversity.tilde <- out_diversity$anomaly
  
  #
  Diversity.surrs <- do.call(cbind,
                             lapply(1:100, function(ii) {
                               I_na <- is.na(Diversity.tilde)
                               out <- Diversity.bar
                               out[I_na] <- NA
                               out[!I_na] <- out[!I_na] + sample(Diversity.tilde[!I_na],sum(!I_na),replace = FALSE)
                               return(out)
                             }))
  
  surrogate_allspeceis<-cbind(surrogate_allspeceis,Diversity.surrs)
}

dim(surrogate_allspeceis) 
write.csv(surrogate_allspeceis,"surrogate_allspeceis.csv")
save(surrogate_allspeceis, file = paste('surrogate_allspeceis','.RData',sep = ""))

load("surrogate_allspeceis.RData")
dim(surrogate_allspeceis) 
plot(surrogate_allspeceis[,1], type="l")
lines(alga_zo[,1],col="red")

############
load("surrogate_allspeceis.RData")
dim(surrogate_allspeceis) 

order_lag_causality<-read.csv("maxlag_rhodifer.csv")
order_lag_causality<-subset(order_lag_causality,significance==1)  
dim(order_lag_causality) 
###### rho of surrogates

i_j_rho<-NULL
j_rho<-NULL

for (i in 1:length(order_lag_causality$i)) {
  
  lag_rho<-NULL
  
  E_star<- E_alg_zoo[order_lag_causality$i[i],2]
  max_range<-c(1:100)+(order_lag_causality$j[i]-1)*100
  
  for (i_surr in  max_range){
    dat_temp <- data.frame(RUE=alga_zo[,order_lag_causality$i[i]], Diversity=surrogate_allspeceis[,i_surr])
    
    lag_rho_surroga <- do.call(cbind,
                               lapply(0, function(ii) {
                                 block_temp = data.frame(laf(dat_temp[,1],dat_temp[,2],lagf=ii))  
                                 colnames(block_temp) = c("RUE","Diversity")                        
                                 lib_ccm <- c(1,NROW(block_temp))
                                 pred_ccm <- make_pred_nozero(block_temp$RUE,E_star)
                                 
                                 df.out.ccm <- ccm(block=block_temp,
                                                   E=E_star,
                                                   lib=lib_ccm,        
                                                   pred = pred_ccm,   
                                                   lib_column = 1,     
                                                   target_column = 2, 
                                                   lib_sizes = NROW(block_temp),    
                                                   exclusion_radius=0,
                                                   random_libs = FALSE,
                                                   num_sample=1,
                                                   tp = 0)
                                 return(df.out.ccm$rho)
                               }))
    
    out.temp<-lag_rho_surroga[which.max(lag_rho_surroga)]
    lag_rho<-cbind(lag_rho, out.temp)} 
  
  j_rho<-cbind(order_lag_causality$i[i],order_lag_causality$j[i],lag_rho)
  i_j_rho<-rbind(i_j_rho,j_rho)
  
  
}

save(i_j_rho, file = paste('rho_in_surrodata(mae24)','.RData',sep = ""))
write.csv(i_j_rho, "rho_in_surrodata(mae24).csv")

load("rho_in_surrodata(mae24).RData")
dim(i_j_rho) #





#
order_lag_causality<-read.csv("maxlag_rhodifer.csv")
order_lag_causality<-subset(order_lag_causality,significance==1)  
dim(order_lag_causality) # 
order_lag_causality$maximum_lag_realdata
colnames(order_lag_causality)<- c("number","X",	"i","j", "lag",	"differenc","significance_mononotic","P_value_mono","rho_mono", "significance",	"maximum_lag_realdata")

#
rho_surrodata1<-read.csv("rho_in_surrodata(mae24).csv") 
rho_surrodata1[,4]
rho_surrodata<-rho_surrodata1[1:dim(rho_surrodata1)[[1]],4:dim(rho_surrodata1)[[2]]]
dim(rho_surrodata) # 
colnames(rho_surrodata1)<-c("number", "i",	"j",	rep("out.temp", times=100) )

############# 
aa<-NULL
bb<-NULL

length(order_lag_causality$maximum_lag_realdata)
#
ou <- data.frame(i=rho_surrodata1$i, j=rho_surrodata1$j, lag=order_lag_causality$lag, rho_difference=order_lag_causality$differenc, 
                 significance_mononotic=order_lag_causality$significance_mononotic,P_value_mono=order_lag_causality$P_value_mono,
                 rho_mono=order_lag_causality$rho_mono,significance=order_lag_causality$significance,
                 max.rho_fromlag_realdata=order_lag_causality$maximum_lag_realdata, significance_surrogates=rep(NA,dim(rho_surrodata1)[[1]]))

for (ii in 1:dim(rho_surrodata)[[1]]) { 
  aa<-rho_surrodata[ii,]
  aa[is.na(aa)] <- 0
  aa[which(aa<0)]<-0
  bb<-(sum(ou$max.rho_fromlag_realdata[ii] < aa) + 1) / (length(aa) + 1)
  ou$significance_surrogates[ii]<-bb 
}

dim(ou) #
head(ou)

write.csv(ou,"interaction_significance.csv") 





### In s-map ###
new_alg_zoo<-read.csv("P.temprature_4_per_years.LE2.2.csv")
dim(new_alg_zoo) 
# scale
alga_zo<-apply(new_alg_zoo[,2:dim(new_alg_zoo)[[2]]], 2, scale) 
head(alga_zo)
dim(alga_zo) 


### 
interaction_significance<-read.csv("interaction_significance.csv")
out<-subset(interaction_significance, significance_surrogates<0.05) 
head(out)               
dim(out) 

###order it                
order_lag_causality<-NULL
for (ii in unique(out$i)) {
  sub_lag_causality<-subset(out, i==ii) 
  sub_lag_causality<-sub_lag_causality[order(sub_lag_causality$lag),] 

  order_lag_causality<- rbind(order_lag_causality,sub_lag_causality)
}

dim(order_lag_causality)



# then, order them
final_order_laga<-NULL

for (ii in unique(order_lag_causality$i)) {
  sub_order_lag_causality<-subset(order_lag_causality, i==ii)
  sub_lag<-sub_order_lag_causality[order(sub_order_lag_causality$lag),] 
  final_order_laga<- rbind(final_order_laga,sub_lag)
}

write.csv(final_order_laga,"caus_ord_lag(mae).csv")
dim(final_order_laga) 





##------------------------ --------##
##----delete indirect links--------##
##------------------------ --------##
library(igraph)
library(MASS)
library(NetIndices)
require(Cairo)


otago.links.data<-read.csv("caus_ord_lag(mae).csv")
otago.links.data<-subset(otago.links.data, i!=j) # exclude i=j
otago.links.data<-subset(otago.links.data, significance_surrogates<0.05) # p<0.05

colnames(otago.links.data)
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(3,4)]))
otago.adjmatrix.c<-get.adjacency(otago.graph.c,sparse=F)
#
diameter(otago.graph.c, unconnected=TRUE)
#
ae=ae2=ae3=ae4=NULL
ag=ah=ai=aj=ak=al=am=NULL
for (i1 in 1:dim(otago.adjmatrix.c)[[2]] ) { 
  
  # via 1 transfer
  a<-otago.adjmatrix.c[i1,] #  1<-- 
  
  if ( length(which(a==1)) >=1 ) { 
    for (i2 in 1:length(which(a==1)) ) {  aa<- which(a==1)
    targe<-aa[i2]
    ab<-aa[-i2]
    for (i3 in ab ) { b<-otago.adjmatrix.c[, targe ] 
    ac<-which(b==1)
    if (i3 %in% ac ){ad<-cbind(targe,i3,i1)
    ae<- rbind(ae,ad)}    } 
    }
  }
  
  # via 2 transfer
  a<-otago.adjmatrix.c[i1,] #  1<-- 
  if ( length(which(a==1)) >=1 ) { 
    for (i2 in 1:length(which(a==1)) ) {  aa<- which(a==1)
    targe<-aa[i2]
    ab<-aa[-i2]
    for (i3 in ab ) { b<-otago.adjmatrix.c[, targe ] # 1th transfer
    ac<-which(b==1)
    ac<- ac[-which(ac==i1)] # remove i1, otherwise have closed loop
    
    treansfer2 <- do.call(rbind,
                          lapply( ac, function(targe2) {
                            c<-otago.adjmatrix.c[, targe2 ] # 2th transfer
                            af<-which(c==1)
                            if (i3 %in% af ){ag<-cbind(targe,targe2,i3,i1)
                            
                            }
                            return(ag)
                          }))
    
    ae2<-rbind(ae2,treansfer2)    } 
    }
  }
  
  
  
  # via 3 transfer
  a<-otago.adjmatrix.c[i1,] #  1<-- 
  if ( length(which(a==1)) >=1 ) { 
    for (i2 in 1:length(which(a==1)) ) {  aa<- which(a==1)
    targe<-aa[i2]
    ab<-aa[-i2]
    for (i3 in ab ) { b<-otago.adjmatrix.c[, targe ] # 1th transfer
    ac<-which(b==1)
    
    ac<- ac[-which(ac==i1)] # remove i1, otherwise have closed loop
    ac<- ac[-which(ac==i3)] # remove i3, otherwise have closed loop
    
    for (i4 in ac ) { c<-otago.adjmatrix.c[, i4 ] # 2th transfer
    ad<-which(c==1)
    
    ad<- ad[-which(ad==i1)] # remove i1, otherwise have closed loop
    ad<- ad[-which(ad==i3)] # remove i3, otherwise have closed loop
    
    treansfer3 <- do.call(rbind,
                          lapply( ad, function(targe3) {
                            c<-otago.adjmatrix.c[, targe3 ] # 3th transfer
                            af<-which(c==1)
                            if (i3 %in% af ){ah<-cbind(targe,i4, targe3,i3,i1)}
                            return(ah)
                          }))
    
    ae3<-rbind(ae3,treansfer3)    } 
    }
    }
    
    
    
  }
  
  
  
  
  
  # via 4 transfer
  a<-otago.adjmatrix.c[i1,] #  1<-- 
  if ( length(which(a==1)) >=1 ) { 
    for (i2 in 1:length(which(a==1)) ) {  
      aa<- which(a==1)
      targe<-aa[i2]
      ab<-aa[-i2]
      for (i3 in ab ) { b<-otago.adjmatrix.c[, targe ] # 1th transfer
      ac<-which(b==1)
      
      ac<- ac[-which(ac==i1)] # remove i1, otherwise have closed loop
      ac<- ac[-which(ac==i3)] # remove i3, otherwise have closed loop
      
      for (i4 in ac ) { c<-otago.adjmatrix.c[, i4 ] # 2th transfer
      ad<-which(c==1)
      
      ad<- ad[-which(ad==i1)] # remove i1, otherwise have closed loop
      ad<- ad[-which(ad==i3)] # remove i3, otherwise have closed loop
      
      for (i5 in ad ) { d<-otago.adjmatrix.c[, i5 ] # 3th transfer
      aee<-which(d==1)
      
      aee<- aee[-which(aee==i1)] # remove i1, otherwise have closed loop
      aee<- aee[-which(aee==i3)] # remove i3, otherwise have closed loop
      aee<- aee[-which(aee==i4)] # remove i4, otherwise have closed loop
      
      
      treansfer4 <- do.call(rbind,
                            lapply( aee, function(targe4) {
                              c<-otago.adjmatrix.c[, targe4 ] # 3th transfer
                              af<-which(c==1)
                              if (i3 %in% af ){ai<-cbind(targe,i4,i5,targe4,i3,i1)}
                              return(ai)
                            }))
      
      ae4<-rbind(ae4,treansfer4)    } 
      }
      }
    }
  }
  
  
  
  
}


# have vaule
ae
ae2
ae3
ae4



ae<- as.data.frame(ae)
if (ncol(ae) ==1) {ae<-t(ae) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae)),nrow=1) )
colnames(newmatrix)<-colnames(ae)
for (i in 1:ncol(ae) ) { newmatrix[1,i]<- ae[1,i] }
#
ae<-c()
ae<-newmatrix
}


ae2<- as.data.frame(ae2)
if (ncol(ae2) ==1) {ae2<-t(ae2) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae2)),nrow=1) )
colnames(newmatrix)<-colnames(ae2)
for (i in 1:ncol(ae2) ) { newmatrix[1,i]<- ae2[1,i] }
#
ae2<-c()
ae2<-newmatrix
}

ae3<- as.data.frame(ae3)
if (ncol(ae3) ==1) {ae3<-t(ae3) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae3)),nrow=1) )
colnames(newmatrix)<-colnames(ae3)
for (i in 1:ncol(ae3) ) { newmatrix[1,i]<- ae3[1,i] }
#
ae3<-c()
ae3<-newmatrix
}

ae4<- as.data.frame(ae4)
if (ncol(ae4) ==1) {ae4<-t(ae4) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae4)),nrow=1) )
colnames(newmatrix)<-colnames(ae4)
for (i in 1:ncol(ae4) ) { newmatrix[1,i]<- ae4[1,i] }
#
ae4<-c()
ae4<-newmatrix
}



#============= first remove repeate ones within
combi<- NULL
if (nrow(ae)>0){
  for (i in dim(ae)[1] ) {  subse<- ae[i,]
  if ( length(subse) > length(unique(subse)) ) {combi<-cbind(combi,i)}} 
  
  if (length(combi)>0){ae<-ae[-combi,]}
}
#
combi<- NULL
if (nrow(ae2)>0){
  for (i in dim(ae2)[1] ) {  subse<- ae2[i,]
  if ( length(subse) >  length(unique(subse)) ) {combi<-cbind(combi,i)} } 
  
  if (length(combi)>0){ae2<-ae2[-combi,]}
}
#
combi<- NULL
if (nrow(ae3)>0){
  for (i in dim(ae3)[1] ) {  subse<- ae3[i,]
  if ( length(subse) > length(unique(subse)) ) {combi<-cbind(combi,i)} } 
  
  if (length(combi)>0){ae3<-ae3[-combi,]}
  
}
#
combi<- NULL
if (nrow(ae4)>0){
  for (i in 1:dim(ae4)[1] ) {  subse<- ae4[i,]
  if ( length(subse) > length(unique(subse)) ) {combi<-cbind(combi,i)} } 
  
  if (length(combi)>0){ae4<-ae4[-combi,]}
  
}
#
ae
ae2
ae3
ae4


#=====
ae<- as.data.frame(ae)
if (ncol(ae) ==1) {ae<-t(ae) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae)),nrow=1) )
colnames(newmatrix)<-colnames(ae)
for (i in 1:ncol(ae) ) { newmatrix[1,i]<- ae[1,i] }
#
ae<-c()
ae<-newmatrix
}


ae2<- as.data.frame(ae2)
if (ncol(ae2) ==1) {ae2<-t(ae2) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae2)),nrow=1) )
colnames(newmatrix)<-colnames(ae2)
for (i in 1:ncol(ae2) ) { newmatrix[1,i]<- ae2[1,i] }
#
ae2<-c()
ae2<-newmatrix
}

ae3<- as.data.frame(ae3)
if (ncol(ae3) ==1) {ae3<-t(ae3) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae3)),nrow=1) )
colnames(newmatrix)<-colnames(ae3)
for (i in 1:ncol(ae3) ) { newmatrix[1,i]<- ae3[1,i] }
#
ae3<-c()
ae3<-newmatrix
}

ae4<- as.data.frame(ae4)
if (ncol(ae4) ==1) {ae4<-t(ae4) 
#
newmatrix<- as.data.frame( matrix(rep(0,times=ncol(ae4)),nrow=1) )
colnames(newmatrix)<-colnames(ae4)
for (i in 1:ncol(ae4) ) { newmatrix[1,i]<- ae4[1,i] }
#
ae4<-c()
ae4<-newmatrix
}



#
number_species=29
need_delete=need_delet=need_deleted=NULL
caus_ord<-read.csv("caus_ord_lag(mae).csv")


for ( l in 1:number_species ) {   #l is end point 
  for ( k in 1:number_species ) { #k is start point
    
    #===== ae
    count_ae<-0
    
    if ( nrow(ae) == 0 ){
      count_ae<-0
      su_ae<-NULL
      su_ae<-as.data.frame(su_ae)
      nrow(su_ae)}
    
    if ( nrow(ae) != 0 ){
      
      sub_ae<- subset(ae,i1==l) 
      #
      if (nrow(sub_ae) ==0) {
        su_ae<-NULL
        su_ae<-as.data.frame(su_ae)
        nrow(su_ae)}
      #
      if (nrow(sub_ae) >=1) {
        su_ae<- subset(sub_ae,targe==k) 
        if ( nrow(su_ae) >=1 ) { sub_caus_ord<- subset(caus_ord, i==l) 
        su_caus_ord<- subset(sub_caus_ord, j==k) #compare with this (longest link)
        for(m in 1:nrow(su_ae) ) {
          
          compare_caus_ord<- subset(caus_ord,j==su_ae$targe[m])  # targe is start point
          compare_caus_or<- subset(compare_caus_ord,i==su_ae$i3[m])# i3 is end point, using this for next
          
          # compare with this
          if (compare_caus_or$max.rho_fromlag_realdata > su_caus_ord$max.rho_fromlag_realdata & compare_caus_or$lag > su_caus_ord$lag) {count_ae<- count_ae+1} } }
      }}
    
    
    #===== ae2
    count_ae2<-0
    
    if ( nrow(ae2) == 0 ){
      count_ae2<-0
      su_ae2<-NULL
      su_ae2<-as.data.frame(su_ae2)
      nrow(su_ae2)}
    
    if ( nrow(ae2) != 0 ){
      
      sub_ae2<- subset(ae2,i1==l) #l is end point
      #
      if (nrow(sub_ae2) ==0) {
        su_ae2<-NULL
        su_ae2<-as.data.frame(su_ae2)
        nrow(su_ae2)}
      #
      if (nrow(sub_ae2) >=1) {
        su_ae2<- subset(sub_ae2,targe==k) #k is start point
        
        if ( nrow(su_ae2) >=1 ) { sub_caus_ord<- subset(caus_ord, i==l) 
        su_caus_ord<- subset(sub_caus_ord, j==k) #compare with this (longest link)
        for(m in 1:nrow(su_ae2) ) {
          
          compare_caus_ord<- subset(caus_ord,j==su_ae2$targe[m])  # targe is start point
          compare_caus_or<- subset(compare_caus_ord,i==su_ae2$targe2[m])# i3 is end point, using this for next
          
          # compare with this
          if (compare_caus_or$max.rho_fromlag_realdata > su_caus_ord$max.rho_fromlag_realdata & compare_caus_or$lag > su_caus_ord$lag) {count_ae2<- count_ae2+1} } }
      }}
    
    #===== ae3
    count_ae3<-0
    
    if ( nrow(ae3) == 0 ){
      count_ae3<-0
      su_ae3<-NULL
      su_ae3<-as.data.frame(su_ae3)
      nrow(su_ae3)}
    
    if ( nrow(ae3) != 0 ){
      
      sub_ae3<- subset(ae3,i1==l)#l is end point
      #
      if (nrow(sub_ae3) ==0) {
        su_ae3<-NULL
        su_ae3<-as.data.frame(su_ae3)
        nrow(su_ae3)}
      #
      if (nrow(sub_ae3) >=1) {
        su_ae3<- subset(sub_ae3,targe==k)#k is start point
        
        if ( nrow(su_ae3) >=1 ) { sub_caus_ord<- subset(caus_ord, i==l) 
        su_caus_ord<- subset(sub_caus_ord, j==k) #compare with this (longest link)
        for(m in 1:nrow(su_ae3) ) {
          
          compare_caus_ord<- subset(caus_ord,j==su_ae3$targe[m])  # targe is start point
          compare_caus_or<- subset(compare_caus_ord,i==su_ae3$i4[m])# i3 is end point, using this for next
          
          # compare with this
          if (compare_caus_or$max.rho_fromlag_realdata > su_caus_ord$max.rho_fromlag_realdata & compare_caus_or$lag > su_caus_ord$lag) {count_ae3<- count_ae3+1} } }           
      }}
    
    
    #===== ae4
    count_ae4<-0       
    
    if ( nrow(ae4) == 0 ){
      count_ae4<-0
      su_ae4<-NULL
      su_ae4<-as.data.frame(su_ae4)
      nrow(su_ae4)}
    
    if ( nrow(ae4) != 0 ){
      
      sub_ae4<- subset(ae4,i1==l)#l is end point
      #
      if (nrow(sub_ae4) ==0) {
        su_ae4<-NULL
        su_ae4<-as.data.frame(su_ae4)
        nrow(su_ae4)}
      #
      if (nrow(sub_ae4) >=1) {
        su_ae4<- subset(sub_ae4,targe==k) #k is start point
        
        if ( nrow(su_ae4) >=1 ) { sub_caus_ord<- subset(caus_ord, i==l) 
        su_caus_ord<- subset(sub_caus_ord, j==k) #compare with this (longest link)
        for(m in 1:nrow(su_ae4) ) {
          
          compare_caus_ord<- subset(caus_ord,j==su_ae4$targe[m])  # targe is start point
          compare_caus_or<- subset(compare_caus_ord,i==su_ae4$i4[m])# i3 is end point, using this for next
          
          # compare with this
          if (compare_caus_or$max.rho_fromlag_realdata > su_caus_ord$max.rho_fromlag_realdata & compare_caus_or$lag > su_caus_ord$lag) {count_ae4<- count_ae4+1} } } 
      }}
    
    
    count_all<- sum(count_ae+count_ae2+count_ae3+count_ae4)
    
    # merge
   if ( count_all >=1 & count_all ==(nrow(su_ae)+nrow(su_ae2)+nrow(su_ae3)+nrow(su_ae4) ) ) {need_delete<-cbind(l,k) } 
    need_delet<-rbind(need_delet, need_delete )
    
  }
  
  need_deleted<-rbind(need_deleted, need_delet )
}

need_deleted<-as.data.frame(need_deleted)
#unique
if( nrow(need_deleted) >0 ){
  need_deleted<-unique(need_deleted) 
  colnames(need_deleted)<-c("end_point","start_point")
}

dim(need_deleted)
write.csv(need_deleted,"need_deleted.csv")


#=============== start remove indirect links
# find it
cau_ord<-read.csv("caus_ord_lag(mae).csv")
which_row <- NULL
if (nrow(need_deleted) > 0 ) {
  for (n in 1:dim(need_deleted)[1] ) {
    
    start_pointt <- need_deleted$start_point[n]
    end_pointt <- need_deleted$end_point[n]
    
    for (o in 1:dim(cau_ord)[1] ) { 
      if( cau_ord$j[o]==start_pointt & cau_ord$i[o]==end_pointt ) {which_row<- rbind(which_row,o)} }
    
  }
}


# remove it
cau_or<-read.csv("caus_ord_lag(mae).csv")
# 
if (length(which_row) ==0) {cau_or2 <- cau_or}

if (length(which_row) > 0) {cau_or2<-cau_or[-which_row,]} 



write.csv(cau_or2,"caus_ord_lag(mae)2.csv")






################################
#### convert to ccm_sig; ccm_rho
otago.links.data<-read.csv("caus_ord_lag(mae)2.csv")
otago.graph.c<-graph.edgelist(as.matrix(otago.links.data[,c(4,5)]))
ccm.sig<-get.adjacency(otago.graph.c,sparse=F)
diag(ccm.sig)<-1

ccm.rho<-matrix(0,nrow=number_species,ncol = number_species, byrow = T)
otago.links.data<-as.data.frame( otago.links.data )
for (k in unique(otago.links.data$i)) { 
  subs<-otago.links.data[otago.links.data$i==k,];
  ccm.rho[k,subs$j]<-subs$max.rho_fromlag_realdata
}
write.csv(ccm.sig,paste('ccm_sig_nin.csv',sep=''),row.names=F)
write.csv(ccm.rho,paste('ccm_rho_nin.csv',sep=''),row.names=F)

ccm.sig <- read.csv(paste('ccm_sig_nin.csv',sep=''),header=T,stringsAsFactors = F)
ccm.rho <- read.csv(paste('ccm_rho_nin.csv',sep=''),header=T,stringsAsFactors = F)



###########  find ds ##############
do <- read.csv('P.temprature_4_per_years.LE2.2.csv',header=T,stringsAsFactors = F)

Emax<-9
out.sample <- F 
nout <- 0  
da.range <- 1:nrow(do) 
Ed<-E_alg_zoo[,2]

dot <- do[da.range,1] # data time
do <- do[da.range,-1] # time series of community data
ndo <- nrow(do)
nin <- ndo-nout # library sample size

# 
(nsp <- ncol(do))                            
dim(do)
# In-sample
do.mean <- apply(do[1:nin,],2,mean,na.rm=T)  # mean abundance in in-sample
do.sd <- apply(do[1:nin,],2,sd,na.rm=T)      # SD of abundance in in-sample
d <- do[1:(nin-1),]                          # In-sample dataset at time t
d_tp1 <- do[2:(nin),]                        # In-sample dataset at time t+1
ds <- (d-repmat(do.mean,nrow(d),1))*repmat(do.sd,nrow(d),1)^-1 # Normalized in-sample dataset at time t
ds_tp1 <- (d_tp1-repmat(do.mean,nrow(d_tp1),1))*repmat(do.sd,nrow(d_tp1),1)^-1 # Normalized in-sample dataset at time t+1
dim(ds_tp1)
# Out-sample
if(out.sample&nout!=0){
  d.test <- do[nin:(ndo-1),]                 # Out-of-sample dataset at time t 
  dt_tp1 <- do[(nin+1):ndo,]                 # Out-of-sample dataset at time t+1
  ds.test <- (d.test-repmat(do.mean,nrow(d.test),1))*repmat(do.sd,nrow(d.test),1)^-1 # Normalized out-of-sample dataset at time t
  dst_tp1 <- (dt_tp1-repmat(do.mean,nrow(dt_tp1),1))*repmat(do.sd,nrow(dt_tp1),1)^-1 # Normalized out-of-sample dataset at time t+1
}else{d.test <- dt_tp1 <- ds.test <- NULL}

# Compiled data at time t 
ds.all <- rbind(ds,ds.test)
dim(ds)


######################################################################
# Perform multiview embedding analysis for each node
# Warning: It is time consuming for running multview embedding for each nodes
do.multiview <- SaveFile <- T
set.seed(49563)

if(do.multiview){
  esele_lag <- esim.lag.demo(ds,ccm.rho,ccm.sig,Ed,kmax=1000,kn=100,max_lag=3,Emax=Emax)
  if(SaveFile){write.csv(esele_lag,paste('eseleLag_nin.csv',sep=''),row.names=F)}
}

#
esele <- read.csv(paste('eseleLag_nin.csv',sep=''),header=T)

####################################################
## The computation of multiview distance
dmatrix.mv <- mvdist.demo(ds,ds.all,esele)
dmatrix.train.mvx <- dmatrix.mv[['dmatrix.train.mvx']]
dmatrix.test.mvx <- dmatrix.mv[['dmatrix.test.mvx']]





######## Leave-one-out cross-validation for finding the optimal parameters for MDR S-map analysis
do.MDR.CV <- F
#
cv.unit <- 0.025
#
cv.unit <- 0.3
#
alpha.so <- seq(0.3, 1, cv.unit);            # Sequence of alpha, more values, longer running time

sub.da <- 5                                # Divide the computation job into five parts 
afsp <- eqsplit(1:length(alpha.so),sub.da) # Divide the parameter space based on alpha parameter
# 
for (alf in 1:1) { 
  
  # Cross-validation   
  if(do.MDR.CV==FALSE){
    alpha.s <- alpha.so                           # Subset parameter pace
    cv.ind <- cv.MDR.demo(ds,ds_tp1,dmatrix.list=dmatrix.train.mvx, parall=T,ncore=1,keep_intra=T,lambda.seq = sort(logspace(-3,0,3),decreasing = T),
                          tht = c(3, 6, 9),
                          alpha.seq=alpha.so)
    
    if(SaveFile){write.csv(cv.ind,paste('_nin_cvunit_alph.csv',sep=''),row.names=F)}
  }
  
} #




################################################################################
# Compiled the CV results tested under different parts of parameter space

CompileCV=T
if(CompileCV){
  cv.ind <- NULL; 
  cv.ind <- read.csv(paste('_nin_cvunit_alph.csv',sep=''),header=T)
  
  # Select the optimal parameter set with the minimal MSE
  paracv.demo <- secv.demo(cv.ind)
  write.csv(paracv.demo,paste('_OptimalCV_Nmvx_Rallx_NEW.csv',sep=''),row.names = F)
}




############################################################
# Fitting MDR S-map based on the parameters selected by CV

do.MDR <- F

do.MDR <- T

cv.unit <- 0.025

cv.unit <- 0.3                          
ptype <- 'aenet'                           # enet:elastic-net or msaenet: adaptive elastic-net

# Select the optimal parameter set with the minimal MSE
paracv.demo <- read.csv("_OptimalCV_Nmvx_Rallx_NEW.csv")

if(do.MDR){
  # Fitting the MDR S-map
  smap.demo <- MDRsmap.demo(paracv=paracv.demo,ptype=ptype,keep_intra=T,out.sample=F,
                            ds,ds_tp1,ds.test,dst_tp1,
                            dmatrix.list=dmatrix.train.mvx,
                            dmatrix.test.list=dmatrix.test.mvx)
  
  # Save forecast skills
  nr.out <- smap.demo[['nr.out']];
  if(SaveFile){
    write.csv(nr.out,paste('_nrout_Nmvx_Rallx_demo_NEW.csv',sep=''),row.names=F)
    write.csv(smap.demo[['jcof']],paste('_jcof_Nmvx_Rallx_demo_NEW.csv',sep=''),row.names=F)
  }
}


### Jacobian
Jocos <- read.csv(paste('_jcof_Nmvx_Rallx_demo_NEW.csv',sep='')) 
traces=NULL
for ( i in 1:nrow(ds)) {
  subs<-subset(Jocos,time==i)
  Jaco<-as.matrix( subs[,5:ncol(subs)] )
  #
  trac<-tr(Jaco)
  traces<-rbind(traces,trac)
}

#
plot(traces,type = "l", ylim=c(0.8,5))
colnames(traces)<-c("traces")
write.csv(traces,"traces.csv")

